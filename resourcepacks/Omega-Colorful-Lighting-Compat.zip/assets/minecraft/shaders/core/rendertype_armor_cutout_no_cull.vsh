#version 150

#moj_import <light.glsl>
#moj_import <colorful_lighting:colored_light.glsl>
#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;
uniform mat3 VerityInvViewRot;

out float vertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec3 vLidarViewPos;
out vec3 vLidarNormal;
out vec3 vWorldRel;
out vec3 vWorldNormal;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexDistance = fog_distance(ModelViewMat, Position, FogShape);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    lightMapColor = sample_lightmap_colored(Sampler2, UV2);
    texCoord0 = UV0;
    texCoord1 = UV1;
    vLidarViewPos = (ModelViewMat * vec4(Position, 1.0)).xyz;
    vLidarNormal = Normal;
    vWorldRel = VerityInvViewRot * vLidarViewPos;
    vWorldNormal = VerityInvViewRot * (mat3(ModelViewMat) * Normal);
}
